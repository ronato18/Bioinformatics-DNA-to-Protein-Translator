"""
Bioinformatics Final Project
Student: ANTO RONALD PIO D
Project: DNA -> RNA -> Codons -> Proteins
"""

header = ""
dna = ""
with open("sample_sequence.fasta", "r") as file:
    for line in file:
        if line.startswith(">"):
            header = line.strip()
        else:
            dna += line.strip().upper()

valid_bases = {"A", "T", "G", "C"}
if not dna or not all (base in valid_bases for base in dna):
    print("❌ Invalid or empty DNA Sequence!")
    exit()

rna = dna.replace("T", "U")
codons = [rna[i:i+3] for i in range(0, len(rna), 3) if len(rna[i:i+3]) == 3]
from full_codon_table import codon_table

protein = []
for codon in codons:
    amino = codon_table.get(codon, "???")
    if amino == "STOP":
        break
    protein.append(amino)





print("Fasta Header:", header)
print("DNA:", dna)
print("RNA:", rna)
print("Codons:", codons)
print("Protein:", protein)

